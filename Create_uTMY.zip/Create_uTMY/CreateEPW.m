%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% uTMY Generator: Urbanized Typical Meteorological Year EPW File Creator
% -------------------------------------------------------------------------
% Description: 
% This script generates urbanized Typical Meteorological Year (uTMY) EPW 
% files by integrating coupled Urban Canopy Model (UCM) outputs with 
% standard meteorological data. It replaces default temperature, humidity, 
% and wind speed values with average canyon air temperature, relative
% humidity, and wind speed to better represent urban microclimate 
% conditions for building energy simulations and urban climate studies.
%
% Methodology:
% 1. Reads base TMY EPW file containing standard meteorological data
% 2. Loads UCM output data for different simulation scenarios
% 3. Replaces dry bulb temperature, relative humidity, and wind speed 
%    with urban canyon values from UCM simulations
% 4. Generates new uTMY EPW file
%
% Key Features:
% - Maintains EPW file format compatibility with building simulation software
% - Preserves all original meteorological parameters except modified ones
%
% Author: Liutao Chen (chenlt@ust.hk; chenlt@uw.edu)
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear

%% Read Base EPW Meteorological File
% --------------------------------------------------------------------
% This section reads the standard Typical Meteorological Year (TMY) file
filename = 'TMY.epw';             % Input EPW file name
fid = fopen(filename, 'r');       % Open file for reading
if fid == -1
    error('Cannot open default EPW file. Please check file existence and path.');
end
 
% Read EPW file header (first 8 lines containing metadata)
header = textscan(fid, '%s', 8, 'Delimiter', '\n');
header = header{1}; 
 

%% Read Meteorological Data Section
% --------------------------------------------------------------------
% EPW files contain 35 columns of hourly meteorological data for full year
% Column definitions based on EnergyPlus EPW format specification
numCols = 35;  % Standard EPW file has 35 columns of meteorological data
TMY_data = textscan(fid, repmat('%s', 1, numCols), 'Delimiter', ',');
fclose(fid);  % Close file after reading

% Initialize uTMY structure with original data
uTMY = TMY_data;


%% Urban Configuration Parameters
% --------------------------------------------------------------------
% These parameters define the urban context for climate modification
LCZ = 4;        % Local Climate Zone
BDtype = 1;     % Building type  
qc = 90;        % West-East canyon orientation
 

%% Load UCM Output Data
% --------------------------------------------------------------------
% Construct filename and load UCM simulation results containing urban
% canyon modifications for temperature, humidity, and wind speed
% UCM output .mat files should be stored in 'UCM_Output_Samples' folder
UCM_output_Filename = sprintf('UCM_Output_Samples\\UCM_sample_LCZ%d_BDtype%d_qc%d.mat', LCZ, BDtype, qc);

% Check if UCM output file exists
if exist(UCM_output_Filename, 'file')
    % Load UCM simulation results 
    Output_sample = load(UCM_output_Filename);
    UCM_output = Output_sample.UCM_output;  % Extract UCM output structure
    [numRows, numCols] = size(UCM_output);

    %% Replace Meteorological Parameters with Urban Values
    uTMY{7} = num2cell(UCM_output.Tcan);   % Replace dry bulb temperature
    uTMY{9} = num2cell(UCM_output.RHcan);  % Replace relative humidity
    uTMY{22} = num2cell(UCM_output.Ucan);  % Replace wind speed

    %% Generate Output uTMY EPW File
    % Create new EPW file with urban-modified meteorological data while
    % preserving original file structure and unmodified parameters
    outputFilename = sprintf('uTMY\\uTMY_LCZ%d_BDtype%d_qc%d.epw', LCZ, BDtype, qc);

     % Open output file for writing
    fid = fopen(outputFilename, 'w');
    if fid == -1
        warning('Cannot create output EPW file %s. Check directory permissions.', outputFilename);
    end

    % Write EPW header (metadata preserved from original)
    for i = 1:length(header)
        fprintf(fid, '%s\n', header{i});
    end

    % Write modified meteorological data section
    for i = 1:numRows
        for j = 1:size(uTMY,2)
            % Format and write each data value with proper comma separation
            if j == size(uTMY,2)
                fprintf(fid, '%s\n', formatEPWValue(uTMY{j}{i}, j));
            else
                fprintf(fid, '%s,', formatEPWValue(uTMY{j}{i}, j));
            end
        end
    end

    fclose(fid);  % Close output file
    fprintf('New uTMY EPW file %s has been created successfully.\n', outputFilename);
    fprintf('Urban parameters: LCZ=%d, Building Type=%d, Canyon Orientation=%d\n', LCZ, BDtype, qc);
    
else
    % Warning if UCM data file not found
    warning('UCM output file %s does not exist. Skipping uTMY generation.', UCM_output_Filename);
end
 


