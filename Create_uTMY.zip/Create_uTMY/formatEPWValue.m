% 
% Helper function: format values in the EPW file
%
function formattedValue = formatEPWValue(value, column)
    if isnumeric(value) || islogical(value)
        if column == 9                                       % Relative Humidity column
            formattedValue = sprintf('%d', round(value));    % No decimal point
        else
            formattedValue = sprintf('%.1f', value);         % Use fixed-point format for other columns
        end
    else
        formattedValue = value;
    end
end